#!/usr/bin/perl -w
my $amtOwed = 0;
my $amtPaid = 0;
my $email = "";
my $name = "";
my $title = "";
my $date = $ARGV[0];

mkdir Emails;

open($IN, "<", "p5Customer.txt") || die "Could not open file\n";
my $lastLine;
while (my $line = <$IN>)
{   
    chomp $line;
    # read customer data into variables by splitting line
    ($email, $name, $title, $amtPaid, $amtOwed) = split (/,/, $line);


    if ($amtOwed > $amtPaid){
        open($IN2, "<", "template.txt") || die "Could not open template\n";
        open($OUT2, ">", "Emails/$email") || die "cannot open email file\n";

        while (my $read = <$IN2>)
        {   
            (my $subLine) = $read =~ s/EMAIL/$email/gr;
            ($subLine) = $subLine =~ s/FULLNAME/$name/gr;
            ($subLine) = $subLine =~ s/NAME/$name/gr;
            ($subLine) = $subLine =~ s/TITLE/$title/gr;
            ($subLine) = $subLine =~ s/AMOUNT/$amtOwed/gr;
            ($subLine) = $subLine =~ s/DATE/$date/gr;
            
            print $OUT2 $subLine;

        }
        close($OUT2);
        close($IN2);
       
        }
}

close($IN); 

